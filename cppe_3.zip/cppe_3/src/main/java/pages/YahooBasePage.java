package pages;


import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

public class YahooBasePage 
{

    protected WebDriver driver;
    final static int IMPLICIT_WAIT_TIME = 30;

    public YahooBasePage(WebDriver drv) {
        driver = drv;

        // Every time we try to reference an element on the page, the AjaxElementLocatorFactory
        // ensures that we wait up to the configured timeout (5 seconds currently), before
        // throwing element not found. This avoids 99% of explicit wait() functions.
        PageFactory.initElements(new AjaxElementLocatorFactory(driver, 60), this);
    }
    
	//Wait until the page is loaded
    protected void waitLoadingPage(WebDriver driver) {
    	new WebDriverWait(driver, IMPLICIT_WAIT_TIME).until((ExpectedCondition<Boolean>) wd ->
		((JavascriptExecutor) wd).executeScript("return document.readyState").equals("complete"));
    }
    
    // yahoo search field
    @FindBy(id = "header-search-input")
    private WebElement yahooSearchBox;

    // yahoo search button
    @FindBy(id = "header-desktop-search-button")
    private WebElement searchButton;

    // yahoo news link
    //@FindBy(xpath = "//*[@id=\"header-nav-bar\"]/li[3]/a")
    @FindBy(linkText = "News")
    private WebElement yahooNews;

    // yahoo home button to return to home page
    @FindBy(id = "logo")
    private WebElement yahooLogo;

    // general search function
    public YahooBasePage yahooSearch(String searchword) {
        yahooSearchBox.click();
        waitLoadingPage(driver);
        yahooSearchBox.sendKeys(searchword);
        searchButton.click();
        return new YahooBasePage(driver);
    }
    
    // click function to return to home page
    public YahooBasePage yahoohome(){
        yahooLogo.click();
        waitLoadingPage(driver);
        return new YahooBasePage(driver);
    }

    // image search function 
    public YahooBasePage news() {
    	yahooNews.click();
        waitLoadingPage(driver);
        return new YahooBasePage(driver);
    }
    
  
    // Just in case we want to take a screenshot of things in the future, 
    // like failures in headless mode.
    public void takeScreenshot(String filePath) {
        TakesScreenshot scrShot = (TakesScreenshot)driver;
        File srcFile = scrShot.getScreenshotAs(OutputType.FILE);
        File destFile = new File(filePath);
        try {
            FileUtils.copyFile(srcFile, destFile);
        }
        catch (IOException e) {
            System.err.println("Failed to save screenshot: " + e.getMessage());
        }
        
    }
}